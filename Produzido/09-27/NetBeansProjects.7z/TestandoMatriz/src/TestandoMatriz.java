
import java.util.Scanner;

public class TestandoMatriz {

    public static void main(String[] args) {
        int matrix[][] = new int[3][3], l, c;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite: ");
        for (l = 0; l < 3; l++) {
            for (c = 0; c < 3; c++) {
                matrix[l][c] = teclado.nextInt();
            }
        }
        System.out.print("\n");
        for (l = 0; l < 3; l++) {
            for (c = 0; c < 3; c++) {
                System.out.print(" " + matrix[l][c]);
            }
            System.out.print("\n");
        }
    }
}
