
import java.util.Scanner;

public class MatrizTransposta {

    public static void main(String[] args) {
        int matriz[][] = new int[5][6], matrizTransposta[][] = new int[6][5], linha, coluna;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Informe o elemento da matriz original: ");
        for (linha = 0; linha < 5; linha++) {
            for (coluna = 0; coluna < 6; coluna++) {
                matriz[linha][coluna] = teclado.nextInt();
            }
        }

        for (linha = 0; linha < 6; linha++) {
            for (coluna = 0; coluna < 5; coluna++) {
                matrizTransposta[linha][coluna] = matriz[coluna][linha];
                System.out.print("\t" + matrizTransposta[linha][coluna]);
            }
            System.out.println("");
        }
    }
}
