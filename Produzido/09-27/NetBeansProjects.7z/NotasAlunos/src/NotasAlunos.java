
import java.util.Scanner;

public class NotasAlunos {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int nota;
        float menor = 0, maior = 0, notas[] = new float[10], somaNotas = 0;
        System.out.println("Informe notas");
        for (nota = 0; nota <= 9; nota++) {
            notas[nota] = teclado.nextFloat();
            somaNotas += notas[nota];
            if (menor == 0 && maior == 0) {
                menor = notas[nota];
                maior = notas[nota];
            } else if (menor > notas[nota]) {
                menor = notas[nota];
            }
            if (maior < notas[nota]) {
                maior = notas[nota];
            }
        }
        System.out.println("Notas digitadas: ");
        for (nota = 0; nota <= 9; nota++) {
            System.out.print(notas[nota] + ";");
        }
        System.out.println("\nMaior nota: " + maior);
        System.out.println("Menor nota: " + menor);
        System.out.println("Média: " + somaNotas / 10);
    }
}
