import java.util.Scanner;
public class TestandoVetores {
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int vetor[] = new int [5];
        System.out.println("Digite valores: ");
        for (int valor = 0; valor < 5; valor++) {
            vetor[valor] = teclado.nextInt();
        }
        System.out.println("Valores que você digitou");
        for (int mostrar= 0; mostrar<5; mostrar++) {
            System.out.print(vetor[mostrar] + "; ");
        }
    }
}
