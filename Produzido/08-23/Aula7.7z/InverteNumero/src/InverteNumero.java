
import javax.swing.JOptionPane;

public class InverteNumero {

    public static void main(String[] args) {
        /*
        int entrada, unidade, dezena, centena, resto, saida;
        Scanner teclado = new Scanner(System.in);
        System.out.print("Digite um valor de 3 dígitos\n-->");
        entrada = teclado.nextInt();
        centena = entrada / 100;
        resto = entrada % 100;
        dezena = resto / 10;
        unidade = resto % 10;
        saida = unidade * 100 + dezena * 10 + centena;
        System.out.println("Número invertido: " + saida);
         */
        int entrada, unidade, dezena, centena, resto, saida;
        entrada = Integer.parseInt(JOptionPane.showInputDialog("Digite um valor de 3 dígitos"));
        centena = entrada / 100;
        resto = entrada % 100;
        dezena = resto / 10;
        unidade = resto % 10;
        saida = unidade * 100 + dezena * 10 + centena;
       JOptionPane.showMessageDialog(null, "Número invertido: " + saida);
    }
}
