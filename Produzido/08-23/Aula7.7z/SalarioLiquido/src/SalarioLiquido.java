
import java.util.Scanner;


public class SalarioLiquido {

    public static void main(String[] args) {
        float horas, valorHora, desconto, salario;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Informe número de horas trabalhadas: ");
        horas = teclado.nextFloat();
        System.out.println("Informe valor de hora: ");
        valorHora = teclado.nextFloat();
        System.out.println("Informe percentual de desconto de INSS: ");
        desconto = teclado.nextFloat();
        salario = horas * valorHora;
        salario -= (salario/100)*desconto;
        System.out.println("Salário líquido: R$" + String.format("%.2f", salario));
    }
}
