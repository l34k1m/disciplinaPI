
import java.util.Scanner;


public class CustoEletricidade {

    public static void main(String[] args) {
        float salarioMinimo, kw, valorKw, valorTotal, valorDesconto;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite o valor do salário mínimo: ");
        salarioMinimo = teclado.nextFloat();
        System.out.println("Digite a quantidade de KW: ");
        kw = teclado.nextFloat();
        valorKw = salarioMinimo / 700;
        valorTotal = valorKw * kw;
        valorDesconto = valorTotal * 0.9f;
        System.out.println("Valor de 1KW: R$" + String.format("%.2f", valorKw));
        System.out.println("Valor total da conta: R$" + String.format("%.2f", valorTotal));
        System.out.println("Valor com 10% de desconto: R$" + String.format("%.2f", valorDesconto));
        System.exit(0);
        
    }
}
